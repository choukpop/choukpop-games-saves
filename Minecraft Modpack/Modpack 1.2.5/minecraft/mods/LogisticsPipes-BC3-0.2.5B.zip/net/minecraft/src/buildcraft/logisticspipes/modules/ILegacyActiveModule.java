package net.minecraft.src.buildcraft.logisticspipes.modules;

import net.minecraft.src.buildcraft.krapht.IProvideItems;

public interface ILegacyActiveModule extends IProvideItems{

}
