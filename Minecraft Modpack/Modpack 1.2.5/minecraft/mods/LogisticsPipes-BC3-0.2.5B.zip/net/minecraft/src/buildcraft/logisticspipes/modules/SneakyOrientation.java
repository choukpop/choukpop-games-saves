package net.minecraft.src.buildcraft.logisticspipes.modules;

public enum SneakyOrientation {
	Default,
	Top,
	Side,
	Bottom,
}
