package ro.narc.liquiduu;

public interface IHasMachineFaces {
    public MachineFace getMachineFace(int side);
}
