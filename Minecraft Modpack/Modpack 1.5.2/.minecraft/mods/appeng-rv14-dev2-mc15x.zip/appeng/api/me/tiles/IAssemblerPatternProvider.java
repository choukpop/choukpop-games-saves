package appeng.api.me.tiles;

import appeng.api.me.util.ICraftingPattern;

/**
 * Both useless and incredibly useful, maybe...
 */
public interface IAssemblerPatternProvider
{
    public ICraftingPattern provideAssemblerPattern();
}
