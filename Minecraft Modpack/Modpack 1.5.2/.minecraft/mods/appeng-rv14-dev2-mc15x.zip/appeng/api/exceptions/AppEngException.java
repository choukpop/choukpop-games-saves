package appeng.api.exceptions;

public class AppEngException extends Exception
{
	
	private static final long serialVersionUID = -9051434206368465494L;

	public AppEngException(String t)
    {
        super(t);
    }
}
